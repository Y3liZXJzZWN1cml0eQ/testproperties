# ============================================================================
# Legacy combined policy file.
# DNS, HTTP, and Network policies are now managed in:
#   - firewall_dns.tf
#   - firewall_http.tf
#   - firewall_network.tf
# ============================================================================
