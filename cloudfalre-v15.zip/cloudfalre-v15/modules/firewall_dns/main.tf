resource "cloudflare_zero_trust_gateway_policy" "this" {
  account_id = var.account_id

  name        = var.name
  description = var.description

  precedence = var.precedence
  enabled    = var.enabled

  action   = var.action
  traffic  = var.traffic
  identity = var.identity

  filters = var.filters
}
