output "id" {
  description = "The ID of the DNS policy"
  value       = cloudflare_zero_trust_gateway_policy.this.id
}

output "name" {
  description = "The name of the DNS policy"
  value       = cloudflare_zero_trust_gateway_policy.this.name
}
