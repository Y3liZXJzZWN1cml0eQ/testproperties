variable "account_id" {
  description = "Cloudflare Account ID"
  type        = string
}

variable "name" {
  description = "Policy name"
  type        = string
}

variable "description" {
  description = "Policy description"
  type        = string
  default     = ""
}

variable "precedence" {
  description = "Policy precedence (lower = higher priority)"
  type        = number
}

variable "enabled" {
  description = "Enable the policy"
  type        = bool
  default     = true
}

variable "action" {
  description = "Action to take (block, allow, etc.)"
  type        = string
  default     = "block"
}

variable "traffic" {
  description = "Traffic expression"
  type        = string
}

variable "identity" {
  description = "Identity expression (which groups to apply to)"
  type        = string
  default     = ""
}

variable "filters" {
  description = "Filters for the policy"
  type        = list(string)
  default     = []
}
