variable "account_id" {
  description = "Cloudflare Account ID"
  type        = string
}

variable "name" {
  description = "Device Profile Name"
  type        = string
}

variable "description" {
  description = "Device Profile Description"
  type        = string
  default     = ""
}

variable "precedence" {
  description = "Evaluation order (lower = higher priority)"
  type        = number
}

variable "enabled" {
  description = "Enable profile"
  type        = bool
  default     = true
}

variable "match" {
  description = "Wirefilter expression used to select users"
  type        = string
}

variable "allow_mode_switch" {
  description = "Allow users to switch WARP modes"
  type        = bool
  default     = false
}

variable "allow_updates" {
  description = "Allow WARP client updates"
  type        = bool
  default     = false
}

variable "allowed_to_leave" {
  description = "Allow users to leave the organization"
  type        = bool
  default     = false
}

variable "auto_connect" {
  description = "Auto connect delay in minutes"
  type        = number
  default     = 0
}

variable "captive_portal" {
  description = "Captive portal timeout"
  type        = number
  default     = 180
}

variable "disable_auto_fallback" {
  description = "Disable automatic fallback"
  type        = bool
  default     = false
}

variable "support_url" {
  description = "Support URL"
  type        = string
  default     = ""
}

variable "switch_locked" {
  description = "Lock the WARP switch"
  type        = bool
  default     = false
}

variable "service_mode_v2" {
  description = "WARP service mode"
  type = object({
    mode = string
    port = optional(number)
  })
  default = {
    mode = "warp"
  }
}

variable "tunnel_protocol" {
  description = "WARP tunnel protocol"
  type        = string
  default     = "masque"
}

variable "exclude" {
  description = "Network exclusions for split tunnel"
  type = list(object({
    address     = optional(string)
    host        = optional(string)
    description = optional(string)
  }))
  default = []
}
