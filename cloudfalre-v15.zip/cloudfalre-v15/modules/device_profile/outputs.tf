output "id" {
  description = "The ID of the device profile"
  value       = cloudflare_zero_trust_device_custom_profile.this.id
}

output "name" {
  description = "The name of the device profile"
  value       = cloudflare_zero_trust_device_custom_profile.this.name
}

output "precedence" {
  description = "The precedence of the device profile"
  value       = cloudflare_zero_trust_device_custom_profile.this.precedence
}
