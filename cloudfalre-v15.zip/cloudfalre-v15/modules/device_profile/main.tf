terraform {
  required_providers {
    cloudflare = {
      source = "cloudflare/cloudflare"
    }
  }
}

resource "cloudflare_zero_trust_device_custom_profile" "this" {
  account_id = var.account_id

  name        = var.name
  description = var.description

  precedence = var.precedence
  enabled    = var.enabled

  match = var.match

  allow_mode_switch     = var.allow_mode_switch
  allow_updates         = var.allow_updates
  allowed_to_leave      = var.allowed_to_leave
  auto_connect          = var.auto_connect
  captive_portal        = var.captive_portal
  disable_auto_fallback = var.disable_auto_fallback

  service_mode_v2 = var.service_mode_v2

  support_url     = var.support_url
  switch_locked   = var.switch_locked
  tunnel_protocol = var.tunnel_protocol
  exclude         = var.exclude
}
