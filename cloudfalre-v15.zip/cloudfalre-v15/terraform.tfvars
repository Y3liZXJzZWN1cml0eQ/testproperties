
# ============================================================================
account_id = "e18e9dde6c948a0ee6b139e54c0505b0"

# The Azure and Cloudflare secret values are intentionally not stored here.
# Keep them in a secure secret manager or CI/CD variables instead.

# ============================================================================
# Device Profile Base Configuration
# ============================================================================
device_profile_config = {
  auto_connect          = 0
  captive_portal        = 180
  disable_auto_fallback = false
  tunnel_protocol       = "masque"
}

# ============================================================================
# Support Email
# ============================================================================
support_email = "infosec@intrusionpanel.info"

# ============================================================================
# Split TUNNEL Custom Exclusions (Applied to ALL Profiles)
# ============================================================================
custom_exclusions = [
  { address = "10.10.10.0/32", description = "Test custom exclusion" },
  { host = "google.com", description = "Exclude google.com" }
]

# ============================================================================
# Custom IP Exclusions per Group (Production)
# ============================================================================
custom_group_exclusions = {
  # IT Team - multiple IPs
  "CF-ZTNA-IT-SCG" = [
    { address = "1.1.2.3", description = "Test IP for IT" }
  ]

  # Security Team - multiple IPs
  "CF-ZTNA-SEC-SCG" = [
    { address = "1.1.2.3", description = "Test IP for SEC" }
  ]

  # Finance Team - multiple IPs
  "CF-ZTNA-FIN-SCG" = [
    { address = "1.1.2.3", description = "Test IP for FIN" }
  ]

  # Operations Team - different IP
  "CF-ZTNA-OPS-SCG" = [
    { address = "1.2.3.4", description = "OPS test IP" },
    { address = "8.8.8.8", description = "google dns" }
  ]

  # Example manual precedence overrides for device profiles.
  # Lower numbers are higher priority.
  # "CF-ZTNA-IT-SCG" = 10
  # "CF-ZTNA-SEC-SCG" = 20

  # Add more groups as needed
  # "CF-ZTNA-ENG-SCG" = []
  # "CF-ZTNA-HR-SCG" = []
  # "CF-ZTNA-LEGAL-SCG" = []
  # "CF-ZTNA-MKT-SCG" = []
  # "CF-ZTNA-SALES-SCG" = []
  # "CF-ZTNA-EXEC-SCG" = []
}

# ============================================================================
# Group Prefix Filter
# ============================================================================
group_prefix = "argus-new"

# ============================================================================
# Optional Manual Device Profile Precedence Overrides
# ============================================================================
# Lower number = higher priority. Omit entries to use automatic alphabetical ordering.
device_profile_precedence_overrides = {
  "argus-new-15"  = 10
  "argus-new-00" = 1
}

# Optional list of exact profile names to keep created but disabled.
# Add more entries here if you want additional profiles disabled.
disabled_device_profiles = [
  "argus-new-IT",
  "argus-new-Roaming",
]
