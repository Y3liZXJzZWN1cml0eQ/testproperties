# ============================================================================
# Outputs
# ============================================================================

output "groups_found" {
  description = "List of Azure AD groups found with the prefix"
  value       = local.group_names
}

output "group_count" {
  description = "Total number of Azure AD groups found"
  value       = local.group_count
}

output "test_ip_groups" {
  description = "Groups that will receive the test IP (1.1.2.3)"
  value       = var.test_ip_groups
}

output "profiles_created" {
  description = "List of device profiles created"
  value = {
    for key, module in module.device_profiles : key => {
      id   = module.id
      name = module.name
    }
  }
}

output "profile_count" {
  description = "Total number of device profiles created"
  value       = length(module.device_profiles)
}

output "match_expression" {
  description = "Match expression for all groups"
  value       = local.match_expression_all
}

output "firewall_policies_created" {
  description = "List of firewall policies created"
  value = {
    dns     = { for key, module in module.firewall_dns : key => { id = module.id, name = module.name } }
    http    = { for key, module in module.firewall_http : key => { id = module.id, name = module.name } }
    network = { for key, module in module.firewall_network : key => { id = module.id, name = module.name } }
  }
}

output "firewall_policy_count" {
  description = "Total number of firewall policies created"
  value = {
    dns     = length(module.firewall_dns)
    http    = length(module.firewall_http)
    network = length(module.firewall_network)
    total   = length(module.firewall_dns) + length(module.firewall_http) + length(module.firewall_network)
  }
}
