# ============================================================================
# Read Azure AD Groups Dynamically
# ============================================================================
# This reads ALL groups with the specified prefix from Azure AD
# No hardcoding - groups come directly from Azure AD
# ============================================================================

data "azuread_groups" "all" {
  display_name_prefix = var.group_prefix
}

# Get the full list of group names for the match expression
locals {
  # All group names starting with the prefix
  group_names = data.azuread_groups.all.display_names

  # Number of groups found
  group_count = length(data.azuread_groups.all.display_names)

  # Build match expression for ALL groups
  # Example: any(identity.groups.name[*] in {"CF-ZTNA-IT-SCG" "CF-ZTNA-SEC-SCG" ...})
  match_expression_all = "any(identity.groups.name[*] in {\"${join("\" \"", local.group_names)}\"})"
}
