# ============================================================================
# DNS Firewall Policies
# ============================================================================
#
# All DNS policies are defined in this file.
#
# To add a new DNS policy:
#   1. Add a new entry inside local.dns_policies
#   2. Run terraform fmt
#   3. Run terraform validate
#   4. Run terraform plan
#
# No terraform init is required when adding/changing DNS policies.
# ============================================================================

locals {
  dns_policies = {

    # ------------------------------------------------------------------------
    # DNS - Block Social Media
    # ------------------------------------------------------------------------
    block_social = {
      name        = "DNS-Block-Social"
      description = "Block social media content categories"
      precedence  = 10020
      enabled     = true
      action      = "block"

      traffic  = "any(dns.content_category[*] in {195})"
      identity = "any(identity.groups.name[*] in {\"CF-ZTNA-ALL\"})"
      filters  = ["dns"]
    }

    # ------------------------------------------------------------------------
    # DNS - Social Media
    # ------------------------------------------------------------------------
    social_media = {
      name        = "DNS--Social"
      description = "Block categories"
      precedence  = 10031
      enabled     = true
      action      = "allow"

      traffic  = "any(dns.content_category[*] in {195 2 67 125 133})"
      identity = "any(identity.groups.name[*] in {\"CF-ZTNA-ALL\"})"
      filters  = ["dns"]
    }

    # ------------------------------------------------------------------------
    # ADD NEW DNS POLICIES BELOW THIS LINE
    # ------------------------------------------------------------------------
    #
    # Example:
    #
    # block_gambling = {
    #   name        = "DNS-Block-Gambling"
    #   description = "Block gambling content categories"
    #   precedence  = 10040
    #   enabled     = true
    #   action      = "block"
    #
    #   traffic  = "CLOUDFLARE_TRAFFIC_EXPRESSION"
    #   identity = "any(identity.groups.name[*] in {\"CF-ZTNA-ALL\"})"
    #   filters  = ["dns"]
    # }

  }
}

# ============================================================================
# DNS Firewall Policy Module
# ============================================================================

module "firewall_dns" {
  for_each = local.dns_policies

  source = "./modules/firewall_dns"

  account_id  = var.account_id
  name        = each.value.name
  description = each.value.description
  precedence  = each.value.precedence
  enabled     = each.value.enabled
  action      = each.value.action
  traffic     = each.value.traffic
  identity    = each.value.identity
  filters     = each.value.filters
}
