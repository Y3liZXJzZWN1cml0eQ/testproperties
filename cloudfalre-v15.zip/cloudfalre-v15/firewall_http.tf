# ============================================================================
# HTTP Firewall Policies
# ============================================================================
#
# All HTTP policies are defined in this file.
#
# To add a new HTTP policy:
#   1. Add a new entry inside local.http_policies
#   2. Run terraform fmt
#   3. Run terraform validate
#   4. Run terraform plan
#
# No terraform init is required when adding/changing HTTP policies.
# ============================================================================

locals {
  http_policies = {

    # ------------------------------------------------------------------------
    # HTTP - Block Social Media
    # ------------------------------------------------------------------------
    block_social = {
      name        = "HTTP-Block-Social"
      description = "Block social media domains"
      precedence  = 2003
      enabled     = true
      action      = "off"

      traffic  = "any(http.conn.domains[*] in {\"instagram.com\" \"facebook.com\"})"
      identity = "any(identity.groups.name[*] in {\"argus-new\"})"
      filters  = ["http"]
    }

    # ------------------------------------------------------------------------
    # ADD NEW HTTP POLICIES BELOW THIS LINE
    # ------------------------------------------------------------------------
    #
    # Example:
    #
    # block_example = {
    #   name        = "HTTP-Block-Example"
    #   description = "Block example domains"
    #   precedence  = 20040
    #   enabled     = true
    #   action      = "block"
    #
    #   traffic  = "any(http.conn.domains[*] in {\"example.com\"})"
    #   identity = "any(identity.groups.name[*] in {\"CF-ZTNA-ALL\"})"
    #   filters  = ["http"]
    # }

  }
}

# ============================================================================
# HTTP Firewall Policy Module
# ============================================================================

module "firewall_http" {
  for_each = local.http_policies

  source = "./modules/firewall_http"

  account_id  = var.account_id
  name        = each.value.name
  description = each.value.description
  precedence  = each.value.precedence
  enabled     = each.value.enabled
  action      = each.value.action
  traffic     = each.value.traffic
  identity    = each.value.identity
  filters     = each.value.filters
}
