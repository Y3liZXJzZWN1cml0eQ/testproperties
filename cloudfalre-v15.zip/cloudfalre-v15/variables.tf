# ============================================================================
# Cloudflare Configuration
# ============================================================================
variable "cloudflare_api_token" {
  description = "Cloudflare API Token"
  type        = string
  sensitive   = true
}

variable "account_id" {
  description = "Cloudflare Account ID"
  type        = string
}

# ============================================================================
# Azure AD Configuration (for reading groups dynamically)
# ============================================================================
variable "azure_tenant_id" {
  description = "Azure AD Tenant ID"
  type        = string
  sensitive   = true
}

variable "azure_client_id" {
  description = "Azure AD Client ID (Service Principal)"
  type        = string
  sensitive   = true
}

variable "azure_client_secret" {
  description = "Azure AD Client Secret (Service Principal)"
  type        = string
  sensitive   = true
}

# ============================================================================
# Device Profile Base Configuration
# ============================================================================
variable "device_profile_config" {
  description = "Base device profile configuration applied to all profiles"
  type = object({
    auto_connect          = number
    captive_portal        = number
    disable_auto_fallback = bool
    tunnel_protocol       = string
  })
  default = {
    auto_connect          = 0
    captive_portal        = 180
    disable_auto_fallback = false
    tunnel_protocol       = "masque"
  }
}

# ============================================================================
# Support Contact
# ============================================================================
variable "support_email" {
  description = "Support email for device profiles"
  type        = string
  default     = "infosec@intrusionpanel.info"
}

# ============================================================================
# Global Custom Exclusions (Applied to ALL Profiles)
# ============================================================================
variable "custom_exclusions" {
  description = "Custom network exclusions to add to all profiles"
  type = list(object({
    address     = optional(string)
    host        = optional(string)
    description = optional(string)
  }))
  default = []
}

# ============================================================================
# Groups to Receive Test IP (1.1.2.3)
# ============================================================================
variable "test_ip_groups" {
  description = "List of Azure AD group names that should receive the test IP (1.1.2.3)"
  type        = list(string)
  default = [
    "CF-ZTNA-IT-SCG",
    "CF-ZTNA-SEC-SCG",
    "CF-ZTNA-FIN-SCG"
  ]
}

# ============================================================================
# Optional Manual Precedence Overrides for Device Profiles
# ============================================================================
variable "device_profile_precedence_overrides" {
  description = "Optional manual precedence values for device profiles keyed by Azure AD group name. If omitted, precedence is automatically assigned by alphabetical order."
  type        = map(number)
  default     = {}

  validation {
    condition = alltrue([
      for _, precedence in var.device_profile_precedence_overrides : precedence >= 1
    ]) && length(distinct(values(var.device_profile_precedence_overrides))) == length(values(var.device_profile_precedence_overrides))
    error_message = "Each device profile precedence override must be a unique positive integer."
  }
}

# ============================================================================
# Device Profiles to Keep Created but Disabled
# ============================================================================
variable "disabled_device_profiles" {
  description = "Exact device profile names to keep created but disabled. Example: CF-ZTNA-SEC-SCG-Corporate."
  type        = list(string)
  default     = []
}

# ============================================================================
# Optional Exact Match Overrides for Specific Device Profiles
# ============================================================================
variable "device_profile_match_overrides" {
  description = "Exact Cloudflare match expressions for specific profiles. Use this when a profile requires a custom match beyond the generated Azure AD group match."
  type        = map(string)
  default = {
    "CF-ZTNA-EXEC-SCG-Corporate" = "any(identity.groups.name[*] in {\"CF-ZTNA-EXEC-SCG\"}) and identity.email in {\"hello@hello.com\" \"admin@hello.com\"}"
  }
}

# ============================================================================
# Group Prefix Filter
# ============================================================================
variable "group_prefix" {
  description = "Prefix to filter Azure AD groups"
  type        = string
  default     = "CF-ZTNA"

  validation {
    condition     = length(trimspace(var.group_prefix)) > 0
    error_message = "group_prefix must not be empty."
  }
}

# ============================================================================
# Custom IP Exclusions per Group
# ============================================================================
variable "custom_group_exclusions" {
  description = "Custom IP exclusions for specific groups"
  type = map(list(object({
    address     = string
    description = optional(string)
  })))
  default = {}
}

# ============================================================================
# DNS Firewall Policies
# ============================================================================
variable "dns_policies" {
  description = "DNS firewall policies to create"
  type = map(object({
    name        = string
    description = string
    precedence  = number
    enabled     = bool
    action      = string
    traffic     = string
    identity    = optional(string, "")
    filters     = optional(list(string), [])
  }))
  default = {}
}

# ============================================================================
# HTTP Firewall Policies
# ============================================================================
variable "http_policies" {
  description = "HTTP firewall policies to create"
  type = map(object({
    name        = string
    description = string
    precedence  = number
    enabled     = bool
    action      = string
    traffic     = string
    identity    = optional(string, "")
    filters     = optional(list(string), [])
  }))
  default = {}
}

# ============================================================================
# Network Firewall Policies
# ============================================================================
variable "network_policies" {
  description = "Network firewall policies to create"
  type = map(object({
    name                 = string
    description          = string
    precedence           = number
    enabled              = bool
    action               = string
    traffic              = string
    identity             = optional(string, "")
    filters              = optional(list(string), [])
    notification_enabled = optional(bool, false)
    notification_message = optional(string, "")
  }))
  default = {}
}
