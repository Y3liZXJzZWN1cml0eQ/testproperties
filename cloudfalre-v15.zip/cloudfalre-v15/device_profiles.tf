# ============================================================================
# Standard Exclusions
# ============================================================================
locals {
  standard_exclusions = [
    { address = "ff05::/16" },
    { address = "ff04::/16" },
    { address = "ff03::/16" },
    { address = "ff02::/16" },
    { address = "ff01::/16" },
    { address = "fe80::/10", description = "IPv6 Link Local" },
    { address = "fd00::/8" },
    { address = "255.255.255.255/32", description = "DHCP Broadcast" },
    { address = "240.0.0.0/4" },
    { address = "224.0.0.0/24" },
    { address = "192.168.0.0/16" },
    { address = "192.0.0.0/24" },
    { address = "172.16.0.0/12" },
    { address = "169.254.0.0/16", description = "DHCP Unspecified" },
    { address = "100.64.0.0/10" },
  ]

  # Create one Corporate and one Roaming profile per Azure AD group.
  # Individual profiles can be kept in Terraform but disabled via
  # var.disabled_device_profiles.
  device_profile_names = sort(flatten([
    for group_name in local.group_names : [
      "${group_name}-Corporate",
      "${group_name}-Roaming",
    ]
  ]))

  device_profile_base_group = {
    for profile_name in local.device_profile_names :
    profile_name => replace(replace(profile_name, "-Corporate", ""), "-Roaming", "")
  }

  disabled_profile_names = toset(var.disabled_device_profiles)

  # Create a map of generated profile name to precedence.
  # Corporate profiles start at 1 and Roaming profiles start at 200.
  # The generated value must remain an integer and unique.
  precedence_map = {
    for idx, profile_name in local.device_profile_names :
    profile_name => lookup(
      var.device_profile_precedence_overrides,
      profile_name,
      endswith(profile_name, "-Corporate")
      ? (idx + 1)
      : 200 + (idx + 1)
    )
  }
}

# ============================================================================
# Dynamically Create Device Profiles for ALL Azure AD Groups
# ============================================================================
# This creates two profiles per Azure AD group: one Corporate and one Roaming.
# ============================================================================

module "device_profiles" {
  for_each = toset(local.device_profile_names)

  source = "./modules/device_profile"

  account_id  = var.account_id
  name        = each.key
  description = "Device profile for ${each.key} (auto-created from Azure AD)"

  precedence = local.precedence_map[each.key]
  enabled    = !contains(local.disabled_profile_names, each.key)

  # Match the underlying Azure AD group for both Corporate and Roaming variants,
  # unless a specific profile override is defined.
  match = lookup(
    var.device_profile_match_overrides,
    each.key,
    "any(identity.groups.name[*] in {\"${local.device_profile_base_group[each.key]}\"})"
  )

  # Standard WARP settings
  allow_mode_switch     = true
  allow_updates         = true
  allowed_to_leave      = true
  auto_connect          = var.device_profile_config.auto_connect
  captive_portal        = var.device_profile_config.captive_portal
  disable_auto_fallback = var.device_profile_config.disable_auto_fallback

  service_mode_v2 = {
    mode = "warp"
  }
  tunnel_protocol = var.device_profile_config.tunnel_protocol

  support_url   = "mailto:${var.support_email}?subject=WARP+website+blocked"
  switch_locked = true

  # ============================================================================
  # Split Tunnel Exclusions
  # ============================================================================
  # 1. Standard exclusions (RFC 1918, etc.) - ALL groups
  # 2. Global custom exclusions - ALL groups (if any defined)
  # 3. Group-specific exclusions - from custom_group_exclusions
  # ============================================================================
  exclude = concat(
    local.standard_exclusions,
    var.custom_exclusions,
    lookup(var.custom_group_exclusions, local.device_profile_base_group[each.key], [])
  )
}
