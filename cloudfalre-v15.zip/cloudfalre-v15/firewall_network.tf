# ============================================================================
# Network Firewall Policies
# ============================================================================
#
# All Network policies are defined in this file.
#
# To add a new Network policy:
#   1. Add a new entry inside local.network_policies
#   2. Run terraform fmt
#   3. Run terraform validate
#   4. Run terraform plan
#
# No terraform init is required when adding/changing Network policies.
# ============================================================================

locals {
  network_policies = {

    # ------------------------------------------------------------------------
    # Network - Block Internal RFC1918
    # ------------------------------------------------------------------------
    block_internal = {
      name        = "Network-Block-Internal"
      description = "Block RFC1918 internal ranges for users in the group"
      precedence  = 30010
      enabled     = true
      action      = "block"

      traffic  = "net.dst.ip in {10.0.0.0/8 172.16.0.0/12 192.168.0.0/16}"
      identity = "any(identity.groups.name[*] in {\"CF-ZTNA-ALL\"})"
      filters  = []

      notification_enabled = true
      notification_message = "This internal network destination has been blocked by policy."
    }

    # ------------------------------------------------------------------------
    # ADD NEW NETWORK POLICIES BELOW THIS LINE
    # ------------------------------------------------------------------------
    #
    # Example:
    #
    # block_specific_network = {
    #   name        = "Network-Block-Specific"
    #   description = "Block specific network destination"
    #   precedence  = 30020
    #   enabled     = true
    #   action      = "block"
    #
    #   traffic  = "net.dst.ip in {10.10.10.0/24}"
    #   identity = "any(identity.groups.name[*] in {\"CF-ZTNA-ALL\"})"
    #   filters  = []
    #
    #   notification_enabled = true
    #   notification_message = "This network destination has been blocked by policy."
    # }

  }
}

# ============================================================================
# Network Firewall Policy Module
# ============================================================================

module "firewall_network" {
  for_each = local.network_policies

  source = "./modules/firewall_network"

  account_id  = var.account_id
  name        = each.value.name
  description = each.value.description
  precedence  = each.value.precedence
  enabled     = each.value.enabled
  action      = each.value.action
  traffic     = each.value.traffic
  identity    = each.value.identity
  filters     = each.value.filters

  notification_enabled = each.value.notification_enabled
  notification_message = each.value.notification_message
}
