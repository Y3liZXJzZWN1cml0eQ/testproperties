$envFile = Join-Path $PSScriptRoot '.env'

if (-not (Test-Path $envFile)) {
    throw "Missing .env file: $envFile"
}

$entries = Get-Content $envFile | Where-Object {
    $_.Trim() -and -not $_.Trim().StartsWith('#')
}

foreach ($entry in $entries) {
    $name, $value = $entry -split '=', 2

    if (-not $name.Trim() -or $null -eq $value) {
        throw "Invalid .env entry. Expected NAME=VALUE."
    }

    Set-Item "Env:$($name.Trim())" $value.Trim().Trim('"')
}

Write-Output "Loaded $($entries.Count) environment variables."
